/******************************************************************************
Entradas y salidas
Escriba un programa que lea 8 datos de entrada y muestre 5 datos como salida, 
según los requerimientos que se explican en seguida, en las secciones "Entrada" y "Salida".

Entrada
Cada entrada consiste exactamente de 8 datos, siempre en el siguiente orden:

    caracter
    caracter
    caracter
    cadena (longitud variable)
    entero
    entero
    entero
    flotante (6 decimales)
    
La salida consiste siempre en 5 datos. 
El primer dato de salida es la concatenación de las primeras cuatro entradas (caracter+caracter+caracter+cadena).
Los datos restantes son las entradas 5 a la 8, los números idénticos sin ningún cambio

*******************************************************************************/
import java.util.Scanner;
import java.text.DecimalFormat;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    char a,b,c;
	    String d;
	    int e,f,g;
	    float h;
	    DecimalFormat f6 = new DecimalFormat("#.######");
	    a = sc.next().charAt(0);
	    b = sc.next().charAt(0);
	    c = sc.next().charAt(0);
	    d = sc.nextLine();
	    e = sc.nextInt();
	    f = sc.nextInt();
	    g = sc.nextInt();
	    h = sc.nextFloat();
	    
	    System.out.println("out: "+a+" "+b+" "+c+" "+d+""+e+" "+f+" "+g+" "+f6.format(h));
	}
}
