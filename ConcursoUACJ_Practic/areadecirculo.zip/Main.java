/*Entrada: un numero entero
* Salida: El área del circulo
*Formula: PI * r^2
*/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner leer = new Scanner(System.in);
		
		int radio = leer.nextInt();
		System.out.System.out.println(radio*radio*Math.PI);
	}
}
