import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner leer = new Scanner();
		
		int a = leer.nextInt();
		int b = leer.nextInt();
		
		System.Out.System.out.println(a+b);
	}
}
