/******************************************************************************
Problema
Calcula el volumen de un edificio dados sus lados: base, altura y ancho separados por espacios.

Entrada
Deberás leer los lados correspondientes al edificio.

Salida
El volumen del edificio

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int b,al,an;
		b.nextInt();
		al.nextInt();
		an.nextInt();
		System.out.println(b*al*an);
	}
}
