/******************************************************************************
1 Galon = 4 Cuartas
1 Cuarta = 2 pintas
1 pinta = 2 tazas
1 taza = 8 onzas

input = 31 41 59 26 57 output = 50 2 1 1 1
Algoritmo
1. 57 entre 8 son 7 tazas y sobra 1 onzas
2. Sumar 7 tazas mas 26
3. 33 entre 2 son 16 pintas y sobra 1 tazas
4. Sumar 16 pintas mas 59
5. 75 entre 2 son 37 cuartas y sobra 1 pinta
6. Sumar 37 + 41 son 78 cuartas
7. 78/4 son 19 galones y sobran 2 cuartas
8. Sumar 31 + 19 son 50 galones
9. Imprimir la nueva representacion
*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
        // int galon, Cuarta, pinta, taza, onzas, r=Residuo
        int g,c,p,t,o;
        
        Scanner sc = new Scanner(System.in);
        
        g = sc.nextInt();
        c = sc.nextInt();
        p = sc.nextInt();
        t = sc.nextInt();
        o = sc.nextInt();
        /*
            1 Galon = 4 Cuartas
            1 Cuarta = 2 pintas
            1 pinta = 2 tazas
            1 taza = 8 onzas
        */
        //Onzas a Tazas
        t = t + (o/8); // Se suma la conversion de onzas a tazas
        o = o % 8;//El residuo se queda en onzas
        //Tazas a Pintas
        p = p + (t/2);
        t = t % 2;
        //Pintas a Cuarta
        c = c + (p/2);
        p = p % 2;
        //Cuarta a Galones
        g = g + (c/4);
        c = c % 4;
        System.out.println(g+" "+c+" "+p+" "+t+" "+o);
    }
}


